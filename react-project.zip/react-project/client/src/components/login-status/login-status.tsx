import React, { Component } from 'react';
import { connect } from "react-redux";
import Button from '@material-ui/core/Button';
import { Link } from 'react-router-dom';
import { withRouter, RouteComponentProps } from 'react-router';

type PathParamsType = {}

type PropsType = RouteComponentProps<PathParamsType> & {}

interface Props extends PropsType {
    auth: any;
    logout: any;
    history: any;
}

interface State {
}

class LoginStatus extends Component<Props, State> {

    logout() {
        this.props.logout();
        this.props.history.push('/login');
    }

    public render(): JSX.Element {
        return (
            <div>
                {
                    this.props.auth.user &&
                    <div className="loginstatus">
                        {this.props.auth.user.firstName}
                        <Button onClick={() => this.logout()} className="white" color="inherit">Logout?</Button>
                    </div>
                }
                {
                    !this.props.auth.user &&
                    <div>
                        <Link to='/register'>
                            <Button className="white" color="inherit">Register</Button>
                        </Link>
                        <Link to='/login'>
                            <Button className="white" color="inherit">Login</Button>
                        </Link>
                    </div>
                }
            </div>
        )
    }
}


const mapStateToProps = (state: any, ownProps: any) => ({
    auth: state.auth,
});

const mapDispatchToProps = (dispatch: any) => ({
    logout: () => dispatch({ type: 'LOGOUT', payload: {} }),
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(LoginStatus));