import React, { Component, ChangeEvent } from 'react';
import './register-form.css';
import TextField from '@material-ui/core/TextField';
import useForm from "react-hook-form";
import * as yup from 'yup';
import Button from '@material-ui/core/Button';

const RegisterFormSchema = yup.object().shape({
    firstname: yup.string().required().min(2),
    lastname: yup.string().required().min(2),
    password: yup.string().required().min(4),
    username: yup.string().required().min(4)
});

export function RegisterForm(props) {

    const { register, handleSubmit, watch, errors } = useForm({ validationSchema: RegisterFormSchema });
    const onSubmit = data => { props.onSubmit(data); }

    return (
        <div className="form-container">
            <form className="form" onSubmit={handleSubmit(onSubmit)}>
                <div className="form-header">
                    <i className="material-icons">
                        person_outline
                            </i>
                    <h2>Register New Account</h2>
                </div>

                <TextField name="firstname" label="firstname" fullWidth style={{ marginTop: 20 }} inputRef={register} />
                <span className="error-message">
                    {errors.firstname && errors.firstname.type === "required" && "Firstname is required"}
                    {errors.firstname && errors.firstname.type === "min" && "Firstname required to be more than 2 characters"}
                </span>

                <TextField name="lastname" label="lastname" fullWidth style={{ marginTop: 20 }} inputRef={register} />
                <span className="error-message">
                    {errors.lastname && errors.lastname.type === "required" && "lastname is required"}
                    {errors.lastname && errors.lastname.type === "min" && "lastname required to be more than 2 characters"}
                </span>

                <TextField name="username" label="username" fullWidth style={{ marginTop: 20 }} inputRef={register} />
                <span className="error-message">
                    {errors.username && errors.username.type === "required" && "username is required"}
                    {errors.username && errors.username.type === "min" && "username required to be more than 4 characters"}
                    {errors.username && errors.username.type === "checkDuplUsername" && "username already exist!"}
                </span>

                <TextField type="password" name="password" label="password" fullWidth style={{ marginTop: 20 }} inputRef={register} />
                <span className="error-message">
                    {errors.password && errors.password.type === "required" && "password is required"}
                    {errors.password && errors.password.type === "min" && "password required to be more than 4 characters"}
                </span>

                <div className="form-footer">
                    <Button variant="contained" type="submit" color="primary" className="form-submit" >
                        Register
                    </Button>
                </div>
            </form>
        </div>)
}