import React, { Component, ChangeEvent } from 'react';
import './register.css';
import { RegisterForm } from '../register-form/register-form';
import axios from 'axios';
import qs from 'qs';
import { connect } from "react-redux";
import to from 'await-to-js';

interface Props {
    loginSuccess: any;
    history: any;
}

interface State {
    error: string;
}

class RegisterComponent extends Component<Props, State>{
    async onSubmit(form) {
        const [error, repsonse] = await to(axios({
            url: "/api/register",
            method: "POST",
            data: qs.stringify(form)
        }));

        if (error) {
            return this.onRegisterFailed(error);
        }

        const { user, token } = repsonse.data;

        this.props.loginSuccess({ user, token });

        this.props.history.push('/vacations');
    }

    onRegisterFailed(error) {
        const messages = {
            USER_EXIST: 'This user name is taken.',
            DEFAULT: 'An unknown error occurred. Please try again'
        }

        const errorMessage = messages[error.response.data.error] || messages.DEFAULT;

        this.setState({ ...this.state, error: errorMessage });

        setTimeout(() => {
            this.setState({ ...this.state, error: null });
        }, 2000);
    }

    public render(): JSX.Element {

        return (
            <div className="register-page">
                <RegisterForm onSubmit={(e) => this.onSubmit(e)}></RegisterForm>
                <div>
                    {this.state && this.state.error && <div className="error-message text-center">{this.state.error}</div>}
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state: any, ownProps: any) => ({
    auth: state.auth,
});

const mapDispatchToProps = (dispatch: any) => ({
    loginSuccess: ({ user, token }) => dispatch({ type: 'LOGIN_SUCCESS', payload: { user, token } }),
});

export const Register = connect(mapStateToProps, mapDispatchToProps)(RegisterComponent);    