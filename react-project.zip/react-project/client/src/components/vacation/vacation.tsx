import React, { Component } from 'react';
import './vacation.css';

import Tooltip from '@material-ui/core/Tooltip';

import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import { Vacation } from '../../models/vacation';
import IconButton from '@material-ui/core/IconButton';
import Card from '@material-ui/core/Card';
import { IoIosHeartEmpty, IoIosHeart } from "react-icons/io";
import { TiDeleteOutline } from 'react-icons/ti';
import { MdModeEdit } from 'react-icons/md';

export interface Props {
    vacation: Vacation;
    onEdit?: any;
    onDelete?: any;
    toggleFollow?: any;
}

export interface State { }

export class VacationComponent extends Component<Props, State> {
    prefixImagesUrl = `http://localhost:3001/uploads`;

    constructor(props: any) {
        super(props)
    }

    public componentDidMount() {

    }

    private formatDate(originalDate: string): string {
        const formattedDate = new Date(originalDate);
        let day: any = formattedDate.getDate();
        let month: any = formattedDate.getMonth() + 1;
        const year: any = formattedDate.getFullYear();

        if (day < 10) {
            day = "0" + day;
        }

        if (month < 10) {
            month = "0" + month;
        }

        return day + "/" + month + "/" + year;
    }

    public render(): JSX.Element {
        return (
            <div className="vacation">
                {
                    this.props.vacation && (
                        <Card className="card-vacation" key={this.props.vacation.id}>
                            <CardContent>
                                <div className="top-actions">
                                    {
                                        this.props.onEdit && <IconButton color="primary" onClick={(e) => this.props.onEdit(this.props.vacation)}>
                                            <MdModeEdit />
                                        </IconButton>
                                    }
                                    {
                                        this.props.onDelete && <IconButton color="primary" onClick={(e) => this.props.onDelete(this.props.vacation)}>
                                            <TiDeleteOutline />
                                        </IconButton>
                                    }
                                </div>
                                <Typography gutterBottom variant="h5" component="h2">
                                    <span className="target-vacation">{this.props.vacation.target}
                                        {this.props.toggleFollow &&
                                            <Tooltip title="Folllow" placement="bottom-end">
                                                <IconButton color="primary" onClick={(e) => this.props.toggleFollow(this.props.vacation)}>
                                                    {!this.props.vacation.followed && <IoIosHeartEmpty />}
                                                    {!!this.props.vacation.followed && <IoIosHeart />}
                                                </IconButton>
                                            </Tooltip>
                                        }
                                    </span>
                                </Typography>
                                <div className="vacation-date">
                                    <Typography variant="body2" color="textSecondary">
                                        <span><strong>vacations start :</strong></span>
                                        <span>{this.formatDate(this.props.vacation.startDate)}</span>
                                    </Typography>
                                    <Typography variant="body2" color="textSecondary">
                                        <span><strong>vacations end  :</strong></span>
                                        <span> {this.formatDate(this.props.vacation.endDate)}</span>
                                    </Typography>
                                </div>
                                <Typography variant="body2" color="textSecondary">
                                    <span><strong>description :</strong></span>
                                    <span>{this.props.vacation.description}</span>
                                </Typography>
                                <Typography variant="body2" color="textSecondary">
                                    <span><strong>price :</strong></span>
                                    <span>{this.props.vacation.price} ILS</span>
                                </Typography>
                                <div className="image-vacation" >
                                    <img src={`${this.prefixImagesUrl}/${this.props.vacation.picture}`} />
                                </div>
                            </CardContent>
                        </Card >
                    )
                }
            </div >
        )
    }
}