import React, { Component } from 'react';
import './vacations.css';
import io from "socket.io-client";
import { Vacation } from '../../models/vacation';
import axios from 'axios';
import { connect } from "react-redux";
import { VacationComponent } from '../vacation/vacation';
import to from 'await-to-js';

interface Props {
    auth: any;
}

export interface State {
    vacations: Vacation[],
}

class VacationsComponent extends Component<Props, State> {
    prefixImagesUrl = `http://localhost:3001/uploads`;
    socket = null;

    constructor(props: any) {
        super(props)
        this.state = {
            vacations: []
        }
    }

    get userVacations() {
        return this.state.vacations.filter(v => v.followed)
    }

    get nonUserVacations() {
        return this.state.vacations.filter(v => !v.followed)
    }

    public async componentDidMount() {

        const [error, response] = await to(axios({
            url: `/api/vacation`,
            method: 'get'
        }));

        if (error) { return; }

        let { vacations } = response.data;

        this.setState({ ...this.state, vacations });

        this.initSocket();
    }

    initSocket() {
        this.socket = io('http://localhost:3001/', {
            origins: "http://localhost:3001/"
        });

        this.socket.on('connect', () => {
            console.log('in connect')
        });

        this.socket.on('vacationChange', (eventName, payload) => {
            console.log({ eventName, payload });
            this[eventName](payload);
        });

        this.socket.on('disconnect', () => {
            console.log('disconnected');
        });
    }

    componentWillUnmount() {
        if (this.socket) {
            this.socket.disconnect();
        }
    }

    addVacation(vacation) {
        const vacations = [...this.state.vacations, vacation];

        this.setState({ ...this.state, vacations });
    }

    updateVacation(vacation) {

        const vacations = this.state.vacations.map(v =>
            v.id === vacation.id
                ? { ...v, ...vacation }
                : v
        );

        this.setState({ ...this.state, vacations });
    }

    deleteVacation(vacation) {
        const { id } = vacation;

        const vacations = this.state.vacations.filter(v => v.id !== id);

        this.setState({ ...this.state, vacations });
    }

    async follow(vacation) {
        const [error, response] = await to(axios({
            url: `/api/vacation/${vacation.id}/follow`,
            method: 'post'
        }));

        if (error) { return; }

        if (response.data.result === true) {
            const vacations = this.state.vacations.map(v => v.id === vacation.id ? ({ ...v, followed: 1 }) : v);
            this.setState({ ...this.state, vacations })
        }
    }

    async unfollow(vacation) {
        const [error, response] = await to(axios({
            url: `/api/vacation/${vacation.id}/unfollow`,
            method: 'post'
        }));

        if (error) { return; }

        if (response.data.result === true) {

            const vacations = this.state.vacations.map(v => v.id === vacation.id ? ({ ...v, followed: 0 }) : v);

            this.setState({ ...this.state, vacations })
        }
    }

    toggleFollow(vacation) {
        if (vacation.followed) {
            this.unfollow(vacation);
        } else {
            this.follow(vacation);
        }
    }

    public render(): JSX.Element {
        return (
            <div className="vacations">
                <h3 className="vacations-title">Your Vacations:</h3>
                <div className="vacations-container">
                    {
                        this.userVacations && this.userVacations.length ? (
                            this.userVacations.map(vacation => {
                                return <VacationComponent
                                    toggleFollow={(e) => this.toggleFollow(e)}
                                    key={vacation.id}
                                    vacation={vacation}></VacationComponent>
                            })
                        ) : this.userVacations && this.userVacations.length === 0 && (
                            <div className="no-results">No data to display</div>
                        )
                    }
                </div>
                <h3 className="vacations-title">All Vacations:</h3>
                <div className="vacations-container">
                    {
                        this.nonUserVacations && this.nonUserVacations.length ? (
                            this.nonUserVacations.map(vacation => {
                                return <VacationComponent
                                    toggleFollow={(e) => this.toggleFollow(e)}
                                    key={vacation.id}
                                    vacation={vacation}></VacationComponent>
                            })
                        ) : this.nonUserVacations && this.nonUserVacations.length === 0 && (
                            <div className="no-results">No data to display</div>
                        )
                    }
                </div>
            </div>
        )
    }
}


const mapStateToProps = (state: any, ownProps: any) => ({
    auth: state.auth,
});

const mapDispatchToProps = (dispatch: any) => ({});

export const Vacations = connect(mapStateToProps, mapDispatchToProps)(VacationsComponent);    