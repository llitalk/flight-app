import React, { Component, ChangeEvent } from 'react';
import './login-form.css';
import { Link } from 'react-router-dom';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import useForm from "react-hook-form";
import * as yup from 'yup';

const LoginFormSchema = yup.object().shape({
    password: yup.string().required().min(4),
    username: yup.string().required().min(4)
});

export function LoginForm(props) {

    const { register, handleSubmit, errors } = useForm({ validationSchema: LoginFormSchema });
    const onSubmit = data => { props.onSubmit(data); }

    return (
        <div className="form-container">
            <form className="form" onSubmit={handleSubmit(onSubmit)}>
                <div className="form-header">
                    <i className="material-icons">
                        account_circle
                            </i>
                    <h2>Login To Your Account</h2>
                </div>

                <TextField name="username" label="username" fullWidth style={{ marginTop: 20 }} inputRef={register} />
                <span className="error-message">
                    {errors.username && errors.username.type === "required" && "username is required"}
                    {errors.username && errors.username.type === "min" && "username required to be more than 4 characters"}
                </span>

                <TextField type="password" name="password" label="password" fullWidth style={{ marginTop: 20 }} inputRef={register} />
                <span className="error-message">
                    {errors.password && errors.password.type === "required" && "password is required"}
                    {errors.password && errors.password.type === "min" && "password required to be more than 4 characters"}
                </span>

                <div className="form-footer">
                    <Button className="buttonRegister" component={Link} to='/register' color="primary">
                        New user? Register
                    </Button>
                    <Button size="small" color="primary" type="submit">
                        Log In
                    </Button>
                </div>
            </form>
        </div>
    )
}