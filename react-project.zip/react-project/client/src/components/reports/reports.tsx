import React, { Component } from 'react';
import "./reports.css";
import axios from 'axios';

import Chart from 'chart.js';
import { Vacation } from '../../models/vacation';
import to from 'await-to-js';

interface State {
    vacations: Vacation[];
}

interface Props {

}

export class Reports extends Component<Props, State> {

    async componentDidMount() {

        const [error, response] = await to(axios({
            url: `/api/vacation/reports`,
            method: 'get'
        }));
        
        if (error) {
            return;
        }

        let { vacations } = response.data;

        let stats = vacations.reduce((a, c) => {
            const key = c.id;
            if (a[key] === undefined) { a[key] = { c: 0, name: c.target }; }
            if (c.userid) a[key].c = a[key].c + 1;
            return a;
        }, []);

        stats = Object.keys(stats).map(k => ({ name: stats[k].name, count: stats[k].c }))

        this.setState({ ...this.state, vacations });

        const labels = stats.map(s => s.name);
        const data = stats.map(s => s.count);

        this.renderChart({ labels, data });
    }

    renderChart({ labels, data }) {
        let ctx = document.getElementById('myChart');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels,
                datasets: [{
                    label: '# Followers',
                    data,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                    ],
                    borderWidth: 1
                }]
            }
        });
    }

    public render(): JSX.Element {
        return (
            <div className="reports-page">
                <h3>Vacations Report</h3>

                <canvas id="myChart" width="400" height="400"></canvas>

            </div>
        )
    }
} 