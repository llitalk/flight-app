export interface Vacation {
    id: number;
    description: string;
    startDate: string;
    endDate: string;
    price: string;
    picture: string;
    target: string;
    favorite: boolean;
    followed: number;
}
