import axios from 'axios';

const initState = {
    user: null,
    token: null,
    loggedIn: false,
};

const auth = (state = initState, action) => {
    switch (action.type) {
        case 'LOGIN_SUCCESS':
            const { user, token } = action.payload;

            localStorage.setItem('user', JSON.stringify(user));
            localStorage.setItem('token', JSON.stringify({ token }));

            axios.defaults.headers.common.authorization = `TOKEN ${token}`;

            return {
                ...state,
                token,
                user,
                loggedIn: true,
            };
        case 'LOGOUT':
            axios.defaults.headers.common.authorization = null;
            localStorage.removeItem('user');
            localStorage.removeItem('token');
            return { ...initState };
        default:
            return state;
    }
};

export default auth;
