1. execute database/db-vacations.sql to create db with the data.
2. run client: npm start (port 8080).
3. run server: npm start (port 3001).
4. browse to http://localhost:8080/

* users: litalk, litaladmin (admin), shlomil. PASSWORD for all: Aa123456.
* admin users will have reports and admin links. non admin users will have only vacation url.
* all the users can access to login and register page.
* if the user is not auth to access then it will redirect to login page.
* All the pictures are in database/pictures and server/uploads folders.

# Lital Kaminsky