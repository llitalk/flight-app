class Vacation {
    constructor(id, description, target, image, startDate, endDate, price, vacationCountofFollow) {
        this.id = id;
        this.description = description;
        this.target = target;
        this.image = image;
        this.startDate = startDate;
        this.endDate = endDate;
        this.price = price;
        this.vacationCountofFollow = vacationCountofFollow;
    }
}

module.exports = Vacation;
