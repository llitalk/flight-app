class User {
    constructor(id, firstName, lastName, userName, password) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
    }
}

module.exports = User;
