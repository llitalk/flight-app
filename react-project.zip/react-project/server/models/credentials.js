class Credentials {
    constructor(username, password) {
        this.username = username;
        this.password = password;
    }
}

module.exports = Credentials;